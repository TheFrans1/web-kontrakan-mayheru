// Pengaturan WhatsApp & Tahun Copyright
const WA = "6285609389232";
const msg = "Halo, saya tertarik dengan Kontrakan Mayheru. Apakah rumah masih tersedia? Saya ingin bertanya dan menjadwalkan survei.";
document.querySelectorAll("[data-wa]").forEach(a => {
    a.href = `https://wa.me/${WA}?text=${encodeURIComponent(msg)}`;
    a.target = "_blank";
    a.rel = "noopener";
});
document.getElementById("year").textContent = new Date().getFullYear();

// Menu Navigasi Mobile
const menu = document.querySelector(".menu");
const nav = document.querySelector("nav");
menu.addEventListener("click", () => nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));

/* =========================================
   LIGHTBOX GALERI & DENAH (KLIK UNTUK MEMPERBESAR)
========================================= */
const lightbox = document.querySelector(".lightbox");
const lightboxImg = lightbox.querySelector("img");

// Menambahkan ".floorplan-img-wrapper img" agar denah ikut terpilih
const galleryImages = document.querySelectorAll(".gallery img, .floorplan-img-wrapper img");

// Buka lightbox saat gambar diklik
galleryImages.forEach(img => {
    img.addEventListener("click", () => {
        lightboxImg.src = img.src; 
        lightbox.classList.add("open");
        document.body.style.overflow = "hidden"; // Kunci scroll halaman belakang
    });
});

// Fungsi untuk menutup lightbox
function closeLightbox() {
    lightbox.classList.remove("open");
    document.body.style.overflow = "auto"; // Buka kembali scroll halaman
    
    // Hapus sumber gambar setelah animasi transisi selesai (400ms)
    setTimeout(() => { lightboxImg.src = ""; }, 400); 
}

// Tutup saat tombol X diklik
lightbox.querySelector("button").addEventListener("click", closeLightbox);

// Tutup saat area gelap di luar gambar diklik
lightbox.addEventListener("click", e => {
    if (e.target === lightbox) closeLightbox();
});

// Tutup saat tombol Escape di keyboard ditekan
document.addEventListener("keydown", e => {
    if (e.key === "Escape") closeLightbox();
});

/* =========================================
   ANIMASI SCROLL REVEAL (DIPERHALUS)
========================================= */
const revealElements = document.querySelectorAll('.reveal');
const revealOptions = {
    threshold: 0.15, // Animasi terpicu setelah 15% bagian elemen masuk layar
    rootMargin: "0px 0px -60px 0px" // Menunggu elemen sedikit naik ke atas sebelum animasi dimainkan
};

const revealOnScroll = new IntersectionObserver(function(entries, observer) {
    entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('active');
        observer.unobserve(entry.target); // Berhenti memantau setelah animasi selesai
    });
}, revealOptions);

revealElements.forEach(el => revealOnScroll.observe(el));

/* =========================================
   HEADER KACA SAAT SCROLL
========================================= */
const header = document.querySelector("header");
const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 30);
window.addEventListener("scroll", onScroll, { passive: true });
onScroll();

/* =========================================
   ANIMASI MASUK GALERI (BERTAHAP)
========================================= */
const galleryObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const figures = [...document.querySelectorAll(".gallery figure")];
        const index = figures.indexOf(entry.target);
        entry.target.style.transitionDelay = `${(index % 4) * 0.09}s`;
        entry.target.classList.add("in");
        // Hapus delay setelah muncul agar efek hover tetap responsif
        setTimeout(() => { entry.target.style.transitionDelay = ""; }, 1200);
        observer.unobserve(entry.target);
    });
}, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

document.querySelectorAll(".gallery figure").forEach(fig => galleryObserver.observe(fig));


/* =========================================
   ANGKA LUAS BANGUNAN BERJALAN CEPAT (0 → 72 m²)
========================================= */
const areaEl = document.querySelector(".facility-info strong");
if (areaEl) {
    const finalText = areaEl.textContent.trim();          // "72 m²"
    const target = parseInt(finalText, 10) || 0;
    const suffix = finalText.replace(/^\d+/, "");          // " m²"
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (target && !reduceMotion) {
        areaEl.textContent = `0${suffix}`;
        const runCounter = () => {
            const duration = 1600;
            const start = performance.now();
            const tick = now => {
                const p = Math.min((now - start) / duration, 1);
                const eased = 1 - Math.pow(1 - p, 4);       // cepat di awal, melambat lalu berhenti
                areaEl.textContent = `${Math.round(target * eased)}${suffix}`;
                if (p < 1) requestAnimationFrame(tick);
                else areaEl.textContent = finalText;
            };
            requestAnimationFrame(tick);
        };
        new IntersectionObserver((entries, observer) => {
            if (!entries[0].isIntersecting) return;
            setTimeout(runCounter, 500);
            observer.disconnect();
        }, { threshold: 0.6 }).observe(areaEl);
    }
}

/* =========================================
   EFEK KUPU-KUPU SAAT SCROLL
   Kupu-kupu muncul & beterbangan ketika halaman di-scroll
========================================= */
(function () {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    var COLORS = [
        ["#ffd329", "#f59e0b"],
        ["#7dd3a8", "#2f8a4c"],
        ["#f9a8d4", "#ec4899"],
        ["#93c5fd", "#3b82f6"],
        ["#fdba74", "#ea580c"],
        ["#c4b5fd", "#7c3aed"]
    ];
    var MAX = window.innerWidth < 700 ? 8 : 14;

    var layer = document.createElement("div");
    layer.className = "butterfly-layer";
    layer.setAttribute("aria-hidden", "true");
    document.body.appendChild(layer);

    function wingSVG(c1, c2, id) {
        return '<svg viewBox="0 0 50 50" width="100%" height="100%">' +
            '<defs><linearGradient id="bg' + id + '" x1="0" y1="0" x2="1" y2="1">' +
            '<stop offset="0" stop-color="' + c1 + '"/><stop offset="1" stop-color="' + c2 + '"/></linearGradient></defs>' +
            '<path d="M25 25 C 18 4, 2 2, 3 16 C 4 24, 14 26, 25 25 Z" fill="url(#bg' + id + ')" stroke="rgba(0,0,0,.25)" stroke-width=".6"/>' +
            '<path d="M25 26 C 14 28, 6 36, 10 44 C 15 50, 23 38, 25 27 Z" fill="url(#bg' + id + ')" opacity=".9" stroke="rgba(0,0,0,.25)" stroke-width=".6"/>' +
            '<circle cx="11" cy="14" r="2.6" fill="rgba(255,255,255,.75)"/>' +
            '<circle cx="14" cy="38" r="1.8" fill="rgba(255,255,255,.6)"/>' +
            '</svg>';
    }

    var uid = 0;
    var flies = [];

    function spawn(dir) {
        if (flies.length >= MAX) return;
        var c = COLORS[Math.floor(Math.random() * COLORS.length)];
        var size = 22 + Math.random() * 22;
        var el = document.createElement("div");
        el.className = "butterfly";
        el.style.width = size + "px";
        el.style.height = size + "px";
        var flap = (0.14 + Math.random() * 0.12).toFixed(2) + "s";
        el.innerHTML =
            '<div class="butterfly-inner">' +
            '<div class="bf-wing bf-left" style="animation-duration:' + flap + '">' + wingSVG(c[0], c[1], uid++) + '</div>' +
            '<div class="bf-wing bf-right" style="animation-duration:' + flap + '">' + wingSVG(c[0], c[1], uid++) + '</div>' +
            '<div class="bf-body"></div>' +
            '</div>';
        layer.appendChild(el);

        var w = window.innerWidth, h = window.innerHeight;
        // Muncul dari tepi bawah saat scroll ke bawah, dari atas saat scroll ke atas
        var fromSide = Math.random() < 0.35;
        var x, y;
        if (fromSide) {
            x = Math.random() < 0.5 ? -size : w + size;
            y = h * (0.2 + Math.random() * 0.6);
        } else {
            x = Math.random() * w;
            y = dir > 0 ? h + size : -size;
        }
        flies.push({
            el: el,
            x: x, y: y,
            vx: (x < 0 ? 1 : x > w ? -1 : (Math.random() - 0.5)) * (1 + Math.random() * 1.5),
            vy: -dir * (1.2 + Math.random() * 1.6),
            phase: Math.random() * Math.PI * 2,
            wobble: 0.6 + Math.random() * 1.2,
            life: 0,
            maxLife: 260 + Math.random() * 200,
            size: size
        });
    }

    var lastY = window.scrollY;
    var lastSpawn = 0;
    var running = false;
    var scrollBoost = 0;

    window.addEventListener("scroll", function () {
        var y = window.scrollY;
        var delta = y - lastY;
        lastY = y;
        if (delta === 0) return;
        scrollBoost = Math.min(scrollBoost + Math.abs(delta) * 0.02, 4);
        var now = performance.now();
        if (now - lastSpawn > 180) {
            lastSpawn = now;
            spawn(delta > 0 ? 1 : -1);
            if (Math.abs(delta) > 40) spawn(delta > 0 ? 1 : -1);
        }
        if (!running) { running = true; requestAnimationFrame(tick); }
    }, { passive: true });

    function tick() {
        var w = window.innerWidth, h = window.innerHeight;
        scrollBoost *= 0.94;
        for (var i = flies.length - 1; i >= 0; i--) {
            var f = flies[i];
            f.life++;
            f.phase += 0.05;
            var speed = 1 + scrollBoost * 0.5;
            f.x += (f.vx + Math.sin(f.phase) * f.wobble) * speed;
            f.y += (f.vy + Math.cos(f.phase * 1.3) * f.wobble * 0.8) * speed;
            var angle = Math.atan2(f.vy, f.vx + Math.sin(f.phase) * f.wobble) * 180 / Math.PI + 90;

            var opacity = 1;
            if (f.life < 20) opacity = f.life / 20;
            else if (f.life > f.maxLife - 40) opacity = Math.max(0, (f.maxLife - f.life) / 40);

            f.el.style.opacity = opacity;
            f.el.style.transform = "translate3d(" + f.x + "px," + f.y + "px,0) rotate(" + angle.toFixed(1) + "deg)";

            var out = f.x < -120 || f.x > w + 120 || f.y < -120 || f.y > h + 120;
            if (f.life >= f.maxLife || (out && f.life > 60)) {
                f.el.remove();
                flies.splice(i, 1);
            }
        }
        if (flies.length) requestAnimationFrame(tick);
        else running = false;
    }
})();
